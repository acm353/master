

public class Philosophen implements Runnable{
	private int id;
	
	
	
	public Philosophen(int ID) {
		id = ID;
	}
	
	
	

	@Override
	public void run() {
//		if () {
//			
//			System.err.println(""); 
//
//		} else {
//			
//			System.err.println(""); 
//		}
	}
	
	
	



	
	
}
