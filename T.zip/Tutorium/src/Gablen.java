
public class Gablen {
	private boolean[] gablen;

	public Gablen() {
		gablen = new boolean[5];
	}

	public synchronized void getGabel(int gableNummer) {
		if (gableNummer < 0 || gableNummer >= gablen.length) {
			throw new IllegalArgumentException(" Gablen existiert nicht !!");
		}
		while (gablen[gableNummer]) { //keine Gabel vorhanden
			try {
				wait();
			} catch (InterruptedException e) {
			}

		}
		if (gablen[gableNummer] == true) {
			gablen[gableNummer] = false;
		}

	}

	public synchronized void putGabel(int gableNummer) {
		if (gableNummer < 0 || gableNummer >= gablen.length) {
			throw new IllegalArgumentException(" Gablen existiert nicht !!");
		}
		while (gablen[gableNummer] == true) {
			try {
				wait();
			} catch (InterruptedException e) {
			}

		}
		if (gablen[gableNummer] == false) {
			gablen[gableNummer] = true;
		}
	}

}
