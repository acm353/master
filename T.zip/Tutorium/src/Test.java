

public class Test {

	public Test() {

	}
	

	public static void main(String[] args) {

		
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
