
public class wohnzimmer {

	public static void main(String[] args) {
		Gablen gable = new Gablen();

		Philosophen Ph1 = new Philosophen(1);
		Philosophen Ph2 = new Philosophen(2);
		Philosophen Ph3 = new Philosophen(3);
		Philosophen Ph4 = new Philosophen(4);
		Philosophen Ph5 = new Philosophen(5);

	}

}
