
public class g {

	
	public g() {
	}
	
	

}
